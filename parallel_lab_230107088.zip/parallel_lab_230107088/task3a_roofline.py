"""Phase 3A roofline microbenchmarks. --quick uses reduced sizes."""
import argparse
import multiprocessing as mp
import time
from multiprocessing import shared_memory
from harness import run_benchmark,emit_verify_tag
STUDENT_ID=230107088
P_PHYS=8

def copy_worker(args):
    src_name,dst_name,lo,hi=args
    src=shared_memory.SharedMemory(name=src_name)
    dst=shared_memory.SharedMemory(name=dst_name)
    a=b=None
    try:
        a=memoryview(src.buf)[lo:hi]
        b=memoryview(dst.buf)[lo:hi]
        b[:]=a
    finally:
        if a is not None: a.release()
        if b is not None: b.release()
        src.close();dst.close()

def compute_worker(iterations):
    # 16 independent scalar accumulators, one multiply-add each per iteration.
    x=[1.0+j*.001 for j in range(16)]
    a=0.999999999; b=0.000000001
    for _ in range(iterations):
        x[0]=x[0]*a+b; x[1]=x[1]*a+b
        x[2]=x[2]*a+b; x[3]=x[3]*a+b
        x[4]=x[4]*a+b; x[5]=x[5]*a+b
        x[6]=x[6]*a+b; x[7]=x[7]*a+b
        x[8]=x[8]*a+b; x[9]=x[9]*a+b
        x[10]=x[10]*a+b; x[11]=x[11]*a+b
        x[12]=x[12]*a+b; x[13]=x[13]*a+b
        x[14]=x[14]*a+b; x[15]=x[15]*a+b
    return sum(x)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--quick',action='store_true');args=ap.parse_args()
    size=2_000_000 if args.quick else 96_000_000
    # 80 million FLOPs per worker = 2.5 million iterations * 16 expressions * 2 FLOPs.
    iterations=2500 if args.quick else 2_500_000
    warm,timed=(0,2) if args.quick else (1,3)
    src=shared_memory.SharedMemory(create=True,size=size)
    dst=shared_memory.SharedMemory(create=True,size=size)
    try:
        # Initialize the source outside the timed region.
        src.buf[:]=b'\x55'*size
        segments=[(src.name,dst.name,size*t//P_PHYS,size*(t+1)//P_PHYS) for t in range(P_PHYS)]
        with mp.Pool(P_PHYS) as pool:
            bw=run_benchmark(lambda:pool.map(copy_worker,segments),warm,timed)
            compute=run_benchmark(lambda:pool.map(compute_worker,[iterations]*P_PHYS),warm,timed)
    finally:
        src.close();dst.close();src.unlink();dst.unlink()
    # Measured bytes copied: read + write.
    bandwidth=2*size/(bw.median_ms*1e6)
    flops=P_PHYS*iterations*16*2
    peak=flops/(compute.median_ms*1e6)
    ridge=peak/bandwidth
    print(f'PHASE3A | quick={args.quick}')
    print(f'Bandwidth median_ms={bw.median_ms:.4f}; GB/s={bandwidth:.6f}')
    print(f'Compute median_ms={compute.median_ms:.4f}; GFLOP/s={peak:.6f}')
    print(f'Ridge FLOP/byte={ridge:.6f}')
    print('Note: Python multiply+add counts as 2 FLOPs but is not hardware fused FMA.')

if __name__=='__main__':
    mp.freeze_support();main()
