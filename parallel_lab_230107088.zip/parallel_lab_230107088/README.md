# Parallel computing practice lab

Python 3 standard library only. Keep all scripts and `harness.py` in the same folder.

Run quick checks first:

```powershell
python task1_falsesharing.py --quick
python task2_scaling.py --quick
python task3a_roofline.py --quick
python task3b_gemm.py --quick
python task4_scheduling.py --quick
```

Then run full experiments (these may take many hours on a laptop):

```powershell
python task1_falsesharing.py > phase1.txt
python task2_scaling.py > phase2.txt
python task3a_roofline.py > phase3a.txt
python task3b_gemm.py > phase3b.txt
python task4_scheduling.py > phase4.txt
```

IMPORTANT: Quick mode uses reduced workloads and cannot be submitted as full-scale measurements. Phase 3A's Python scalar multiply-add is not hardware-fused FMA. Phase 3B timing includes clearing the output matrix; document that convention. Phase 4 has a very large number of trig operations and may run for a long time. Phase 0 hash metric conventions must be confirmed with the instructor.

Do not invent measurements; use the raw outputs from your own system.
