"""Phase 4: skewed scheduling; --quick checks functionality on smaller N."""
import argparse
import math
import multiprocessing as mp
import time
from harness import emit_verify_tag
STUDENT_ID=230107088
P_PHYS=8
CHUNKS=(1,4,16,64,256,1024)

def work_item(i):
    count=1+(i*i)//3600  # floor((i/60)^2), exact for integer i
    total=0.0
    for k in range(count):
        x=(k+1)*.00001
        total+=math.sin(x)*math.cos(x)+math.sqrt(x)
    return total

def worker(t,p,n,kind,chunk,counter,times):
    start=time.perf_counter_ns()
    if kind=='block':
        for i in range(n*t//p,n*(t+1)//p): work_item(i)
    elif kind=='cyclic':
        for i in range(t,n,p): work_item(i)
    else:
        while True:
            with counter.get_lock():
                first=counter.value
                counter.value+=chunk
            if first>=n: break
            for i in range(first,min(first+chunk,n)): work_item(i)
    times[t]=(time.perf_counter_ns()-start)/1e6

def experiment(p,n,kind,chunk):
    times=mp.Array('d',p)
    counter=mp.Value('i',0)
    jobs=[mp.Process(target=worker,args=(t,p,n,kind,chunk,counter,times)) for t in range(p)]
    start=time.perf_counter_ns()
    for job in jobs: job.start()
    for job in jobs: job.join()
    wall=(time.perf_counter_ns()-start)/1e6
    if any(job.exitcode!=0 for job in jobs): raise RuntimeError('Scheduling worker failed')
    durations=list(times)
    avg=sum(durations)/p
    imbalance=max(durations)/avg if avg else float('nan')
    return wall,imbalance

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--quick',action='store_true');args=ap.parse_args()
    n=600 if args.quick else 12_000
    p=P_PHYS
    results=[]
    print('PHASE4: strategy,chunk,wall_ms,lambda',flush=True)
    for kind,chunk in [('block',0),('cyclic',0)]+[('dynamic',x) for x in CHUNKS]:
        wall,imbalance=experiment(p,n,kind,chunk)
        print(f'{kind},{chunk},{wall:.4f},{imbalance:.4f}',flush=True)
        results.append((kind,chunk,wall))
    best=min((x for x in results if x[0]=='dynamic'),key=lambda x:x[2])
    print(f'Best dynamic chunk={best[1]}',flush=True)
    print(emit_verify_tag('PHASE4',STUDENT_ID,results[0][2],best[2]))

if __name__=='__main__':
    mp.freeze_support();main()
