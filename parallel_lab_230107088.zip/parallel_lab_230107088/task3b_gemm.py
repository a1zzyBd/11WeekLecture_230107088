"""Phase 3B GEMM. Shared matrices, row-parallel workers, tile sweep."""
import argparse
import ctypes
import multiprocessing as mp
from multiprocessing import shared_memory
from harness import run_benchmark,emit_verify_tag
STUDENT_ID=230107088
P_PHYS=8
BLOCK_SIZES=(4,8,12,16,24,32,48,64,96,128)

def worker(args):
    a_name,b_name,c_name,n,first,last,kind,bs=args
    sa=shared_memory.SharedMemory(name=a_name)
    sb=shared_memory.SharedMemory(name=b_name)
    sc=shared_memory.SharedMemory(name=c_name)
    A=(ctypes.c_double*(n*n)).from_buffer(sa.buf)
    B=(ctypes.c_double*(n*n)).from_buffer(sb.buf)
    C=(ctypes.c_double*(n*n)).from_buffer(sc.buf)
    try:
        if kind=='naive':
            for i in range(first,last):
                for j in range(n):
                    acc=0.0
                    for k in range(n): acc+=A[i*n+k]*B[k*n+j]
                    C[i*n+j]=acc
        elif kind=='reordered':
            for i in range(first,last):
                for k in range(n):
                    a=A[i*n+k]
                    for j in range(n): C[i*n+j]+=a*B[k*n+j]
        else:
            for ii in range(first,last,bs):
                for jj in range(0,n,bs):
                    for kk in range(0,n,bs):
                        for i in range(ii,min(ii+bs,last)):
                            for k in range(kk,min(kk+bs,n)):
                                a=A[i*n+k]
                                for j in range(jj,min(jj+bs,n)):
                                    C[i*n+j]+=a*B[k*n+j]
    finally:
        del A,B,C
        sa.close();sb.close();sc.close()

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--quick',action='store_true');args=ap.parse_args()
    n=48 if args.quick else 384
    p=4 if args.quick else P_PHYS
    warm,timed=(0,1) if args.quick else (1,3)
    size=n*n*8
    sa=shared_memory.SharedMemory(create=True,size=size)
    sb=shared_memory.SharedMemory(create=True,size=size)
    sc=shared_memory.SharedMemory(create=True,size=size)
    A=(ctypes.c_double*(n*n)).from_buffer(sa.buf)
    B=(ctypes.c_double*(n*n)).from_buffer(sb.buf)
    C=(ctypes.c_double*(n*n)).from_buffer(sc.buf)
    try:
        for i in range(n*n):
            A[i]=(i%17+1)/17
            B[i]=(i%13+1)/13
        def execute(pool,kind,bs=1):
            for idx in range(n*n): C[idx]=0.0
            jobs=[(sa.name,sb.name,sc.name,n,n*t//p,n*(t+1)//p,kind,bs) for t in range(p)]
            pool.map(worker,jobs)
        def capture(): return list(C)
        with mp.Pool(p) as pool:
            print('PHASE3B: variant,bs,median_ms,GFLOP/s,tile_bytes',flush=True)
            best=None; baseline=None; reference=None
            for kind,bs in [('naive',1),('reordered',1)]+[('blocked',x) for x in BLOCK_SIZES]:
                # Benchmark includes matrix reset; consistent across variants.
                stats=run_benchmark(lambda k=kind,b=bs:execute(pool,k,b),warm,timed)
                execute(pool,kind,bs)
                if kind=='reordered': reference=capture()
                if kind=='blocked' and reference is not None:
                    error=max(abs(x-y) for x,y in zip(C,reference))
                    if error>=1e-9: raise AssertionError(f'GEMM mismatch: {error}')
                gflops=2*n**3/(stats.median_ms*1e6)
                print(f'{kind},{bs},{stats.median_ms:.4f},{gflops:.6f},{3*bs*bs*8 if kind=="blocked" else 0}',flush=True)
                if kind=='naive': baseline=gflops
                if kind=='blocked' and (best is None or gflops>best[1]): best=(bs,gflops)
            print(f'Best tile BS={best[0]}, GFLOP/s={best[1]:.6f}',flush=True)
            print(emit_verify_tag('PHASE3',STUDENT_ID,baseline,best[1]))
    finally:
        del A,B,C
        sa.close();sb.close();sc.close()
        sa.unlink();sb.unlink();sc.unlink()

if __name__=='__main__':
    mp.freeze_support();main()
