"""Phase 1: shared-memory false sharing. Run --quick to smoke-test."""
import argparse
import ctypes
import multiprocessing as mp
from multiprocessing import shared_memory
from harness import run_benchmark, emit_verify_tag

STUDENT_ID=230107088
P_PHYS=8
P_LOG=16
STRIDES=(1,2,4,8,16,32)

def worker(name, slot, iters):
    shm=shared_memory.SharedMemory(name=name)
    arr=(ctypes.c_uint64*512).from_buffer(shm.buf)
    try:
        acc=arr[slot]
        for i in range(iters):
            acc=(acc*6364136223846793005+(i|1))&0xFFFFFFFFFFFFFFFF
            arr[slot]=acc
    finally:
        del arr
        shm.close()

def trial(p,stride,total):
    shm=shared_memory.SharedMemory(create=True,size=4096)
    try:
        jobs=[]
        for t in range(p):
            count=total//p+(t<total%p)
            proc=mp.Process(target=worker,args=(shm.name,t*stride,count))
            jobs.append(proc)
        for proc in jobs: proc.start()
        for proc in jobs: proc.join()
        if any(proc.exitcode!=0 for proc in jobs):
            raise RuntimeError('A false-sharing worker failed')
    finally:
        shm.close()
        shm.unlink()

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--quick',action='store_true')
    args=ap.parse_args()
    total=240_000 if args.quick else 24_000_000
    warm,timed=(0,2) if args.quick else (2,7)
    print(f'PHASE1 | total={total} | quick={args.quick}',flush=True)
    results={}
    print('TABLE 1A: stride, separation_bytes, median_ms, iqr_ms, Mops/s',flush=True)
    for stride in STRIDES:
        stats=run_benchmark(lambda s=stride:trial(P_PHYS,s,total),warm,timed)
        results[(P_PHYS,stride)]=stats.median_ms
        print(f'{stride},{stride*8},{stats.median_ms:.4f},{stats.iqr_ms:.4f},{total/stats.median_ms/1000:.4f}',flush=True)
    print('TABLE 1B: stride, p, median_ms, speedup, efficiency, karp_flatt',flush=True)
    for stride in (1,16):
        base=None
        for p in (1,2,4,8,16):
            if (p,stride) in results:
                median=results[(p,stride)]
            else:
                median=run_benchmark(lambda p=p,s=stride:trial(p,s,total),warm,timed).median_ms
            if p==1: base=median
            speed=base/median
            efficiency=speed/p
            karp=(1/speed-1/p)/(1-1/p) if p>1 else float('nan')
            print(f'{stride},{p},{median:.4f},{speed:.4f},{efficiency:.4f},{karp:.4f}',flush=True)
    print(emit_verify_tag('PHASE1',STUDENT_ID,results[(P_PHYS,1)],results[(P_PHYS,16)]))

if __name__=='__main__':
    mp.freeze_support()
    main()
