"""Phase 2: strong and weak scaling. Persistent pool created outside timing."""
import argparse
import math
import multiprocessing as mp
import time
from harness import run_benchmark,emit_verify_tag
STUDENT_ID=230107088
P_PHYS=8
P_LOG=16

def serial_stage(n):
    out=0.0
    for i in range(int(n*.05)):
        x=(i+1)*0.00001
        for j in range(6):
            out+=math.sin(x+j*.001)+math.sqrt(x+j*.001)
    return out

def parallel_worker(bounds):
    start,end=bounds
    out=0.0
    for i in range(start,end):
        x=(i+1)*0.00001
        for j in range(35):
            x=x*1.00000001+0.0000001
            x+=math.sin(x)*0.000001
        out+=x
    return out

def partition(n,p):
    return [(n*t//p,n*(t+1)//p) for t in range(p)]

def experiment(pool,n,p,warm,timed):
    chunks=partition(n,p)
    stage_a=[]
    def once():
        t0=time.perf_counter_ns()
        serial_stage(n)
        stage_a.append((time.perf_counter_ns()-t0)/1e6)
        pool.map(parallel_worker,chunks)
    stats=run_benchmark(once,warm,timed)
    # Serial stage is measured independently to avoid assuming identical stage timing.
    a=run_benchmark(lambda:serial_stage(n),warm,timed).median_ms
    return stats.median_ms,a

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--quick',action='store_true')
    args=ap.parse_args()
    strong_n=16000 if args.quick else 1_600_000
    weak_n0=2500 if args.quick else 250_000
    warm,timed=(0,2) if args.quick else (2,7)
    limit=4 if args.quick else P_LOG
    strong=[]; weak=[]
    print(f'PHASE2 | quick={args.quick}',flush=True)
    print('STRONG: p,N,median_ms,stageA_ms,speedup,efficiency',flush=True)
    for p in range(1,limit+1):
        with mp.Pool(p) as pool:
            t,a=experiment(pool,strong_n,p,warm,timed)
        strong.append((t,a))
        speed=strong[0][0]/t
        print(f'{p},{strong_n},{t:.4f},{a:.4f},{speed:.4f},{speed/p:.4f}',flush=True)
    print('WEAK: p,N,median_ms,stageA_ms,efficiency,gustafson',flush=True)
    for p in range(1,limit+1):
        n=p*weak_n0
        with mp.Pool(p) as pool:
            t,a=experiment(pool,n,p,warm,timed)
        weak.append((t,a))
        alpha=a/t
        gust=p-alpha*(p-1)
        print(f'{p},{n},{t:.4f},{a:.4f},{weak[0][0]/t:.4f},{gust:.4f}',flush=True)
    s=strong[0][1]/strong[0][0]
    observed=strong[0][0]/strong[-1][0]
    gust=limit-(weak[-1][1]/weak[-1][0])*(limit-1)
    print(f'Serial fraction={s:.6f}; Amdahl max={1/s:.4f}; Amdahl at p={limit}: {1/(s+(1-s)/limit):.4f}',flush=True)
    print(emit_verify_tag('PHASE2',STUDENT_ID,observed,gust))

if __name__=='__main__':
    mp.freeze_support()
    main()
